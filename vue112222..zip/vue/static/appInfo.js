var app_info = {
  api_host: "https://zjz.jiankeweb.com/",
  version: "1.6.1",
};
module.exports = app_info;
